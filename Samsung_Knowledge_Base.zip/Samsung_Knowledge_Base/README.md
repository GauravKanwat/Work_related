# Samsung Knowledge Base

This repository serves as a personal engineering knowledge base
documenting projects, technical decisions, debugging methodologies,
achievements, and lessons learned.

## Suggested workflow

-   Update each project after major milestones.
-   Record pain points and how they were solved.
-   Capture commands, scripts, and useful references.
-   Add interview-friendly summaries after completing each project.
