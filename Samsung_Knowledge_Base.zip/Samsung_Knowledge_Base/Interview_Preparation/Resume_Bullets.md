# Resume Bullets
