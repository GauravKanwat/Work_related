# kernel debugging

## Purpose

## Commands

## Examples
